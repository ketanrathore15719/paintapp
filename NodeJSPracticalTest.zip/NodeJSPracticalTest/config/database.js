const mongoose = require("mongoose");
const { config } =  require("dotenv");
config({ path: "./config/config.env" });

//let mongoDB_URL = process.env.MONGO_URI || 'mongodb+srv://rkrathod:uXo26iJx9qPHo14m@cluster0.iiwyy.mongodb.net/teste?authSource=admin&replicaSet=atlas-a0ke2y-shard-0&w=majority&readPreference=primary&appname=MongoDB%20Compass&retryWrites=true&ssl=true'
let mongoDB_URL = 'mongodb+srv://therealrathore:H8WgLMnG1sRfkmTU@cluster0.anaamsn.mongodb.net/?retryWrites=true&w=majority'
const connectDatabase = async () => {
  try {
    const { connection } = await mongoose.connect(mongoDB_URL);
    console.log(`MongoDB connected:- ${connection.host}:${connection.port}`);
  } catch (error) {
    console.log('KKKK', error);
    process.exit(1);
  }
};

module.exports = connectDatabase